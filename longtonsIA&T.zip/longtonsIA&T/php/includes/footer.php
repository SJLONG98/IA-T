<div class="footer">
	 <?php echo "<h2>FOOTER</h2>";?>
</div>