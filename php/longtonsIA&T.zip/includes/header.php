<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<link rel="stylesheet" href="style.css">
<title>FILO</title>
<h2>Welcome to FILO</h2>
<div >
	<ul>
	  <li>
	    <a  href="index.php">Items</a>
	  </li>
	  <li>
	    <a href="Requests.php">Requests</a>
	  </li>
	  <li>
	    <a  href="Admin.php">Admin</a>
	  </li>
	  <li>
	    <a href="login.php">Login</a>
	  </li>
	  <li>
	    <a  href="register.php">Register</a>
	  </li>
	</ul>
</div>
